# Вычислить скалярное произведение
import numpy as np

a = np.array([1, 5], float)
b = np.array([2, 8], float)
print(np.dot(a, b))
print(np.inner(a, b))